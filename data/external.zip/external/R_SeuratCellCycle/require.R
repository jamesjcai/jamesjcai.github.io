if (!requireNamespace("Matrix", quietly = TRUE)){
    install.packages("Matrix", repo="http://cran.rstudio.com/")
}
if (!requireNamespace("Seurat", quietly = TRUE)){
    install.packages("Seurat", repo="http://cran.rstudio.com/")
}
