if (!requireNamespace("SoupX", quietly = TRUE)){
    install.packages("SoupX", repo="http://cran.rstudio.com/")
}
if (!requireNamespace("rhdf5", quietly = TRUE)){
    install.packages("rhdf5", repo="http://cran.rstudio.com/")
}