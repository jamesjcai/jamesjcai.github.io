#define EUCLIDEAN  0
#define MANHATTAN  1
#define L_INFINITY 2
#define L_P        3
