require("ENCORE")
# https://academic.oup.com/nar/article/49/3/e18/6030236