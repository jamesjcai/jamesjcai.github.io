function y = postvar(sum2,n,a,b)
	y=(.5.*sum2+b)./(n/2+a-1);
end