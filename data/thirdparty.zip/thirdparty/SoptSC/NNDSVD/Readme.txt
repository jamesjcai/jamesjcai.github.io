This package contains three files:

- nndsvd.m
- pos.m
- neg.m

You have to run the file nndsvd.m  for the NNDSVD algorihm [1]. The other two are supporting files.

For questions send an email to : boutsc@cs.rpi.edu (Christos Boutsidis)  

[1] C. Boutsidis and E. Gallopoulos, SVD-based initialization: A head
    start for nonnegative matrix factorization, Pattern Recognition,
    Elsevier