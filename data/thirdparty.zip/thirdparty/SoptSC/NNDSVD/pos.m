function [Ap] = pos(A)
Ap = (A>=0).*A;
