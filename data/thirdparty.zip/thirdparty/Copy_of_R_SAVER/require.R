if (!requireNamespace("SAVER", quietly = TRUE)){
    install.packages("SAVER", repo="http://cran.rstudio.com/")
}
if (!requireNamespace("R.matlab", quietly = TRUE)){
    install.packages("R.matlab", repo="http://cran.rstudio.com/")
}